
import java.util.*;
import java.io.*;
public class data
{
    double mean;
    double variance;
    double popvariance;
    double quartile[];
    double mode[];
    double median;
    double x[];
    double xf[];
    double lowerb[];
    double upperb[];
    double xsort[];
    double freq[];
    double collecteddata[];

    public double[] collectdata(int est, String s) throws IOException
    {
        ArrayList arr = new ArrayList(est);
        StringTokenizer st = new StringTokenizer(s, ","); 
        while (st.hasMoreTokens()) {
            String temp=st.nextToken();
            if (temp.equals("end")==false)
            {
                arr.add(temp);
            }

        }
        double array[]=new double[arr.size()];
        for (int i=0; i<arr.size(); i++)
        {
            array[i]=Double.parseDouble((String)arr.get(i));
        }
        return array;
    }

    public double mean(double a[])
    {
        double sum=0;
        for (int i=0; i<a.length; i++)
        {
            sum=sum+a[i];
        }
        double average=sum/a.length;
        return average;
    }

    public double median(double a[])
    {
        int x=a.length-1;
        double median;
        for(int i=0;i<x-1;i++)
        {
            for(int j=0;j<(x-1)-i;j++)
            {
                if(a[j]>a[j+1])
                {
                    double temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
        }
        xsort=a;
        if (a.length%2==0)
        {
            median=(a[a.length/2]+a[(a.length/2)+1])/2;
        }
        else
        {
            median=a[(a.length+1)/2];
        }
        return median;
    }

    public double[] mode(double a[])
    {
        int x=a.length-1;
        double modea[];
        double freq=0;
        for(int i=0;i<x-1;i++)
        {
            for(int j=0;j<(x-1)-i;j++)
            {
                if(a[j]>a[j+1])
                {
                    double temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
        }
        ArrayList<Double> xvar = new ArrayList<Double>();
        ArrayList<Double> f = new ArrayList<Double>();
        xvar.add(a[0]);
        for (int i=0;i<a.length-1;i++)
        {
            if (a[i]==a[i+1])
            {
                freq=freq+1;
            }
            else
            {
                f.add(freq);
                xvar.add(a[i+1]);
                freq=0;
            }
        }
        f.add(freq);
        xvar.add(a[a.length-1]);
        double xvara[]=new double[xvar.size()];
        for (int i=0; i<xvar.size(); i++)
        {
            xvara[i]=xvar.get(i);
        }
        double fa[]=new double[f.size()];
        for (int i=0; i<f.size(); i++)
        {
            fa[i]=f.get(i);
        }
        double max=0;
        for (int i=0; i<fa.length; i++)
        {
            if (fa[i]>max)
            {
                max=fa[i];
            }
        }
        int counter=0;
        for (int i=0; i<fa.length; i++)
        {
            if (fa[i]==max)
            {
                counter=counter+1;
            }
        }
        modea=new double[counter];
        for (int i=0; i<counter; i++)
        {
            if (fa[i]==max)
            {
                modea[i]=xvara[i];
            }
        }
        return modea;
    }

    public double variance(double a[])
    {
        double mean=mean(a);
        double sum=0;
        for (int i=0; i<a.length; i++)
        {
            sum=sum+(Math.pow((a[i]-mean),2));
        }
        double variance=sum/a.length;
        return variance;
    }

    public double popvariance(double a[])
    {
        double mean=mean(a);
        double sum=0;
        for (int i=0; i<a.length; i++)
        {
            sum=sum+(Math.pow((a[i]-mean),2));
        }
        double variance=sum/(a.length-1);
        return variance;
    }

    public double[] quartile(double a[])
    {
        int x=a.length-1;
        double lower=0;
        double higher=0;
        for(int i=0;i<x-1;i++)
        {
            for(int j=0;j<(x-1)-i;j++)
            {
                if(a[j]>a[j+1])
                {
                    double temp=a[j];
                    a[j]=a[j+1];
                    a[j+1]=temp;
                }
            }
        }
        if (a.length%4==1)
        {
            lower=a[(a.length-1)/4];
        }
        else if (a.length%4==2)
        {
            lower=(a[(a.length-2)/4]+a[(a.length+2)/4])/2;
        }
        else if (a.length%4==3)
        {
            lower=a[(a.length+1)/4];
        }
        else if (a.length%4==0)
        {
            lower=a[(a.length)/4];
        }

        if (a.length%4==1)
        {
            higher=a[((a.length-1)/(4/3))-1];
        }
        else if (a.length%4==2)
        {
            int k=((3*(a.length-2))/4)-1;
            higher=(a[k]+a[k+1])/2;
        }
        else if (a.length%4==3)
        {
            int k=((3*(a.length+1))/4)-1;
            higher=a[k];
        }
        else if (a.length%4==0)
        {
            int k=((3*(a.length))/4)-1;
            higher=a[k];
        }
        double quartile[]={lower,higher};
        return quartile;
    }

    public void fileprint()
    {
        try
        {
            FileWriter file = new FileWriter ("math data.txt",true);
            file.write("\r\n"+"\r\n");
            file.write("Complete Data value for Statistics Below:  ");
            for (int i=0; i<x.length; i++)
            {
                file.write(x[i] + ",   ");
            }
            file.write("\r\n"+"mean  "+mean);
            file.write("\r\n"+"median  "+median);
            file.write("\r\n"+"mode  ");
            for (int i=0; i<mode.length; i++)
            {
                file.write(mode[i] + ",   ");
            }
            file.write("\r\n"+"variance  "+variance);
            file.write("\r\n"+"standard deviation  "+Math.pow(variance,1/2));
            file.write("\r\n"+"population variance  "+popvariance);
            file.write("\r\n"+"population standard deviation  "+Math.pow(popvariance,1/2));
            file.write("\r\n"+"interquartile range  ");
            for (int i=0; i<2; i++)
            {
                file.write(quartile[i]+ ",   ") ;
            }
            file.close();
        }    
        catch (FileNotFoundException f)
        {
            try
            {
                FileWriter file = new FileWriter ("math data.txt",true);
                file.write("\r\n"+"\r\n");
                file.write("Complete Data value for Statistics Below:  ");
                for (int i=0; i<x.length; i++)
                {
                    file.write(x[i] + ",   ");
                }
                file.write("\r\n"+"mean  "+mean);
                file.write("\r\n"+"median  "+median);
                file.write("\r\n"+"mode  ");
                for (int i=0; i<mode.length; i++)
                {
                    file.write(mode[i] + ",   ");
                }
                file.write("\r\n"+"variance  "+variance);
                file.write("\r\n"+"standard deviation  "+Math.pow(variance,1/2));
                file.write("\r\n"+"population variance  "+popvariance);
                file.write("\r\n"+"population standard deviation  "+Math.pow(popvariance,1/2));
                file.write("\r\n"+"interquartile range  ");
                for (int i=0; i<2; i++)
                {
                    file.write(quartile[i]+ ",   ") ;
                }
                file.close();
            }  
            catch (IOException ex){}
        }
        catch (IOException ex){}
    }

}
