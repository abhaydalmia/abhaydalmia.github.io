import java.util.*;
import java.io.*;
public class main
{
    public int error3=1;
    public static void main (String []args)
    {
        int again=1;
        while (again==1)
        {
            int error1=1;
            int error2=1;
            int error3=1;
            int error4=1;
            int switchvar=0;
            int estimate=0;
            Scanner scan=new Scanner (System.in);
            System.out.println("Input opperator according to requirement");
            System.out.println("For direct data values - 1. For frequency table - 2. For Grouped Data - 3");
            System.out.println("");
            while (error1==1)
            {
                switchvar=scan.nextInt();
                if (switchvar<1 || switchvar>3)
                {
                    System.out.println("Incorrect Opperator. Please try again!");
                    System.out.println("");
                }
                else
                {
                    error1=0;
                }
            }

            switch(switchvar)
            {
                case 1:
                {
                    data obj = new data(); 
                    do
                    {

                        try
                        {
                            Scanner scan3=new Scanner(System.in);
                            System.out.println("Please enter an estimate on the number of data values");
                            System.out.println("NOTE: You can enter as much or as little data as needed."); 
                            System.out.println("This estimate has no affect on that");
                            System.out.println("");
                            estimate=scan3.nextInt();
                            if (estimate>0)
                            {
                                error3=0;
                            }
                            else
                            {
                                System.out.println("Kindly enter a number greater than one");
                                System.out.println("");
                            }
                        }
                        catch (Exception e)
                        {
                            System.out.println("Number should be numerical! Try Again!");
                            System.out.println("");
                            error3=1;
                        }

                    }
                    while (error3==1);

                    do
                    {
                        System.out.println("Enter x values, separated by comma. When finished, enter 'end'");
                        Scanner scan1=new Scanner (System.in);
                        String main=scan1.nextLine();
                        try 
                        {
                            obj.x=obj.collectdata(estimate,main);
                            error2=0;
                        }
                        catch (Exception e)
                        {
                            System.out.println("Some data entered other than 'end' was not numerical. Try Again!");
                            System.out.println("");
                            error2=1;
                        }
                    }
                    while (error2==1);

                    obj.mean=obj.mean(obj.x);
                    obj.median=obj.median(obj.x);
                    obj.mode=obj.mode(obj.x);
                    obj.variance=obj.variance(obj.x);
                    obj.popvariance=obj.popvariance(obj.x);
                    obj.quartile=obj.quartile(obj.x);

                    obj.fileprint();
                    System.out.println("The Data has been appended to file name 'Math Data'");
                    System.out.println("");
                    break;
                }

                case 2:
                {
                    data obj = new data(); 
                    int counter1=0;
                    do
                    {
                        try
                        {
                            System.out.println("Please enter an estimate on the number of data values");
                            System.out.println("NOTE: You can enter as much or as little data as needed."); 
                            System.out.println("This estimate has no affect on that");
                            System.out.println("");
                            estimate=scan.nextInt();
                            if (estimate>0)
                            {
                                error3=0;
                            }
                            else
                            {
                                System.out.println("Kindly enter a number greater than one");
                                System.out.println("");
                            }
                        }
                        catch (Exception e)
                        {
                            System.out.println("Number should be numerical! Try Again!");
                            System.out.println("");
                            error3=1;
                        }
                    }
                    while (error3==1);

                    do
                    {
                        System.out.println("Enter x values, separated by comma. When finished, enter 'end'");
                        Scanner scan1=new Scanner (System.in);
                        String main=scan1.nextLine();
                        try 
                        {
                            obj.x=obj.collectdata(estimate,main);
                            error2=0;
                        }
                        catch (Exception e)
                        {
                            System.out.println("Some data entered other than 'end' was not numerical. Try Again!");
                            System.out.println("");
                            error2=1;
                        }
                    }
                    while (error2==1);
                    error2=0;
                    do
                    {

                        System.out.println("Enter frequency values, separated by comma. When finished, enter 'end'");
                        Scanner scan1=new Scanner (System.in);
                        String main=scan1.nextLine();
                        try 
                        {
                            obj.freq=obj.collectdata(estimate,main);
                            error2=0;
                        }
                        catch (Exception e)
                        {
                            System.out.println("Some data entered other than 'end' was not numerical. Try Again!");
                            error2=1;
                        }
                    }
                    while (error2==1);

                    for (int i=0;i<obj.x.length;i++)
                    {
                        for (int j=0; j<obj.freq[i];j++)
                        {
                            counter1=counter1+1;
                        }
                    }
                    obj.xf=new double[counter1];
                    counter1=0;
                    for (int i=0;i<obj.x.length;i++)
                    {
                        for (int j=0; j<obj.freq[i];j++)
                        {
                            obj.xf[counter1]=obj.x[i];
                            counter1=counter1+1;
                        }
                    }

                    obj.mean=obj.mean(obj.xf);
                    obj.median=obj.median(obj.xf);
                    obj.mode=obj.mode(obj.xf);
                    obj.variance=obj.variance(obj.xf);
                    obj.popvariance=obj.popvariance(obj.xf);
                    obj.quartile=obj.quartile(obj.xf);

                    obj.fileprint();
                    System.out.println("The Data has been appended to file name 'Math Data'");
                    System.out.println("");
                    break;
                }

                case 3:
                {
                    data obj = new data(); 

                    do
                    {
                        try
                        {
                            System.out.println("Please enter an estimate on the number of data values");
                            System.out.println("NOTE: You can enter as much or as little data as needed."); 
                            System.out.println("This estimate has no affect on that");
                            estimate=scan.nextInt();
                            if (estimate>0)
                            {
                                error3=0;
                            }
                            else
                            {
                                System.out.println("Kindly enter a number greater than one");
                            }
                        }
                        catch (Exception e)
                        {
                            System.out.println("Number should be numerical! Try Again!");
                            error3=1;
                        }
                    }
                    while (error3==1);
                    do
                    {
                        do
                        {
                            System.out.println("Enter lower bound values, separated by comma. When finished, enter 'end'");
                            Scanner scan1=new Scanner (System.in);
                            String main=scan1.nextLine();
                            try 
                            {
                                obj.lowerb=obj.collectdata(estimate,main);
                                error2=0;
                            }
                            catch (Exception e)
                            {
                                System.out.println("Some data entered other than 'end' was not numerical. Try Again!");
                                error2=1;
                            }
                        }
                        while (error2==1);
                        error2=0;
                        do
                        {
                            System.out.println("Enter upper bound values, separated by comma. When finished, enter 'end'");
                            Scanner scan1=new Scanner (System.in);
                            String main=scan1.nextLine();
                            try 
                            {
                                obj.upperb=obj.collectdata(estimate,main);
                                error2=0;
                            }
                            catch (Exception e)
                            {
                                System.out.println("Some data entered other than 'end' was not numerical. Try Again!");
                                error2=1;
                            }
                        }
                        while (error2==1);
                        error2=0;
                        do
                        {
                            System.out.println("Enter frequency values, separated by comma. When finished, enter 'end'");
                            Scanner scan1=new Scanner (System.in);
                            String main=scan1.nextLine();
                            try 
                            {
                                obj.freq=obj.collectdata(estimate,main);
                                error2=0;
                            }
                            catch (Exception e)
                            {
                                System.out.println("Some data entered other than 'end' was not numerical. Try Again!");
                                error2=1;
                            }
                        }
                        while (error2==1);

                        if (obj.lowerb.length==obj.upperb.length && obj.upperb.length==obj.freq.length)
                        {
                            error4=0;
                        }
                        else
                        {
                            error4=1;
                        }
                    }
                    while (error4==1);
                    obj.x = new double[obj.upperb.length];

                    for (int i=0; i<obj.upperb.length; i++)
                    {
                        obj.x[i]=(obj.upperb[i]+obj.lowerb[i])/2;
                    }
                    int counter1=0;
                    for (int i=0;i<obj.x.length;i++)
                    {
                        for (int j=0; j<obj.freq[i];j++)
                        {
                            counter1=counter1+1;
                        }
                    }
                    obj.xf=new double[counter1];
                    counter1=0;
                    for (int i=0;i<obj.x.length;i++)
                    {
                        for (int j=0; j<obj.freq[i];j++)
                        {
                            obj.xf[counter1]=obj.x[i];
                            counter1=counter1+1;
                        }
                    }

                    obj.mean=obj.mean(obj.xf);
                    obj.median=obj.median(obj.xf);
                    obj.mode=obj.mode(obj.xf);
                    obj.variance=obj.variance(obj.xf);
                    obj.popvariance=obj.popvariance(obj.xf);
                    obj.quartile=obj.quartile(obj.xf);

                    obj.fileprint();
                    System.out.println("The Data has been appended to file name 'Math Data'");
                    break;
                }
            }
            System.out.println("");
            System.out.println("Do you want to perfrom another calculation? Y/N?");
            System.out.println("");
            System.out.println("");
            Scanner scan2=new Scanner(System.in);
            String redo=scan2.nextLine();
            if (redo.equals("Y")==true||redo.equals("y")==true)
            {
                again=1 ;
            }
            else if (redo.equals("Y")==false||redo.equals("y")==false)
            {
                again=0;
            }
            else
            {
                System.out.println("Input was wrong/did not follow rules! Program will automaticaly end.");
                again=0;
            }
        }
    }
}

